---
title: (Day	88) 
author: 김준회
date: 2024-03-21 16:00:00 +0900
categories: [TIL, 비트캠프]
tags: [TIL, Web, 비트캠프, 네이버클라우드]
pin: true
math: true
mermaid: true
image:
  path: data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMwAAADACAMAAAB/Pny7AAAAaVBMVEX///9tsz9rsjxosTdkry9msDNhrin9/vxerSP6/Plaqxr4+/bz+PDn8eHV6Mt1t0uRxHOHv2bf7djF37eq0ZWu05pxtUW42Kelzo7t9el8ulaZyH601qKVxnnN48GCvV+fy4ZSqAC/3K/FZ8aPAAAOwElEQVR4nM1d6bqiMAy16cK+owgoKO//kNNy1UGh0AKC55tfo1d7JM3WJD0cFiM/YoYBLQBm6OwtX8hSOHlS2GwRkxZA7kGSO3tScf0z2Hgxkz9gE5/9fC8qeVWyFR7KfwBjYbWLuHlJyMiKTP5AWNTEW1PJm5DR1akIUBZlmz4dN4vgO1RaOji6KOydlRhXEaJr7pUeMNSNNbWKcA1lkYd4mVVRAGBcT2wd954s55LaX6fSAtvh6DpCNv76NIwYmVswaUHsypCuxLVx4S7ikqfmWiZSBWCXuYzOjcJpiZxZVb2qjVQAC5JhF8cDQLSczyW/oO+pYxkwTgdV8I1LCI5ma+f4SrYUsSeARFV/MX7ARQSCuXLWFOv7LmogwfFzMdat/V1pOo/LEW8vYk9gHH6ogYo/GG626Sy76V63sS0SAK3fdkd+pciuTC5nAxI4Ba/+rvcyDXzqLjthCAeHAiOWaXPxg/1E7MWGNq/1xJyGHR8SE5FSV86q0/5cOBuSPTaOk3IWV4v7AFzOfC0qRoL30Mh9ADn+2c+KcT+Ue6FWSJGppZyNZu/t8gKwVDhjXkERu4gAQcjZTcc/y8ivcBFszs7BKBkifyrZowCBhhNw+SEugs3t0Ngv1eYKOVPfNJetHcspkNsJEDn+RaFWYyJ2VM21ZT+zX17gKyIvu+8ThGvFTdOgn+PCgYNXPJ1zObPVElMJ/IZOfgfg/9bTupjIzOTR6H9Up1/kgsi5u0YKuJ5M43Cfod7L5R8FectixBF3bKY3TX5le697CKR+W6VzZtx9nuJipdslYTRA6g/HsqGIXqfINL9mYFqQXmLQF3HABBd/11hMBlL3zL0I0+7jytn9SUU2wOVwSAl3AkbJRL+oyPoyJpCcuHIe43L5RUVGikFp8mq+aUYsTfx7HpngIvH1+aYhcuVs1L+3YYBEMtN44d7aTUom/T0umMqX6wc8QpO/+HNkaD+l+R9ugeEkUc5u+QupmC6A1aMOS4gRNMMvJb8Ww2ByGzeKFyzbNF70Yw+GwmXCK44B4WgodnYuP2YuWe1PhSsGAhi0QeI86ocA9lkhwg+5XRzYNCI8+CEQWymPlJH38POB+L73+v8DsOrRuGcjGvaeoPNDux/DkI88DBMNVED49t4UnsC4zhTyFA/UeOAU/VecMkyKo845MvfyyaeP8CM7BszgqFdxFtv904DoFx4MmOjoq6T1OrBsbjbf+cc/oJY5lUusX3Ua8E3z7r+Fuz8YbJ8yT33f/8eNb5o3DeCddjb+7F5UrqaAPZDYiB27v8KuMRlg015Qpe3d38+d3d30MmAu8eGM6oTO4rnZ7PqayR5SBoApBMVVUoalDOG6kI7DcNvY9xc8CBTR9Vgtq+cTsFLSPUSPt5IyQYISxjiPMs38dcp5jeTtcLP5WiDDV4/F+glnYDJGT3VUno9Z4nvLn8gLsajZeGoAd2UpEzLETNO2bUZRUNTRtTyf00uTVL4fe/lMDSyHhwG/KgLWkzKgzLRNGkS3NONLjzk8z8tz13Uda20OL+TiZOOpzpJVAhnM7Du6HrkEicV/ce09uCVBz7DUSRf7ZUBsO0h9x9qQwn84R4bMRwS0UMoAKMGlrq+7Joy2JuhV9LSACkbBTa/sa334Igpo1aOoDZgLipcbcC0MP/+YchPQ6mZxMDiXSpRu3Ic0XMcoKh3vrW72ZuaXKQu37UESGPZIPVFF08q6P0vKwK6T7ZvdvGEy+e3hnVmzzjAZ3v6pcEjKGN0z+zt1dkN9Xwabt3hOgLsUxkny/xmPnK9cObj6W4adqj2ocIf4JnuB8fiMk8nvmlTAvO7V6Aoyg1YRbvA4mUozK4tBv2h9JVSmTCAqHsPY3N5pnmPQYj9zH0WyV0RDzT0/GHq5fxLt1kvN3S5pgblwL+34YOiUYgIp92tzd0pb+kO2NYH+wdHYMm3N926oUCj9du+vMUBDmXEuKwbuusjLuzy7JvxLlukcMe3KhYfDJ7nPIbIY3AVIlD0zptUSsTa8aOzs2T23x7TKnhnpn4JuCKMxx+pkBRl6O5wVNfNHE9vW8CgZ6/0zUk4mPIRqZOC0a2jsXsl4t9yRO2fRoVBzM+llq3UPorLxcF3jE5wMFAc1ISOTpdBfRU6BpKOOOieDFMk8sgW7ISRTDaZCjwVqZOwVRjwsQGMjOuFHCTInJTLks7l4W/gIPo+Te2gtjBIZtvlcmy5c7kT2erU/oUzGHN973wa3hICmDj2PinsGYFdzKQ7CcDH1LlUypkaF0fqoRG3ypJyLY00VOwPBnjvGE10W01bOOYs2x2ky6n2dX4BbMpEOmnRxRQiAw0kyuzplTtsuZo53yAgIMjwEmCKjP0BgRbT9yLiYFg0RaZJ0kgzdLUvGFVnbJ65SRCtyANytnuCCd0yT/c1VYDeFPStSTWZ1CKakbDe97LdcJlz/53t5JMOfYDQez+Dpzfcl+H9tfGqTJSruJNy9w/gZoO7IjfUQ/3FRzKJU3BrdXdEcOPZgVPvt18ZjPgydGkD3QMPNke0cstHsDF4wdmsJ/KLlAkgtkLJE1EyMQzWaN4N9Qn//0fOOz2rqp3UACkOUOI9w2cf8v7ioHjmIJibKQx53lEywh/lPHuPHAKm6uHEAiKVc3Mamsci7Br+I5jlPyZQ0xvXhs793G8XI+cx43/B3cHnOUzJvypkHkTBvvZ6xKsAdlFn6bN+nCv7lA22N2V3siGxEnW1u/63rs7MaTwcxL+R8/8NJvH9MnW3tMnvF0+qBqRHfeu1MPfEg85EnQ7dN/lWnp8jDSCt5H+LA7G+y1ljlvNZHLoXT0KefCPSi4awL+/+YciJyAb/wZLzUfBoJwFoHjg5XyEBasTRGDgKxsqZfDD/6vwysF6qLM2b8OAuLR57MVgrASIL/q6ChXtYxsdGr6yyXb5qtjpi8W2fyINY9cBTrf8Zwrrx6ZiM7U3UHdWKk6Q8K7xJe9U6J1NKMjKdYD07arXjB8poSCRq+fPqaEBxLO4Hw0tHbCvDqrquL79p+epuMTp++T17KVABMZt+XwjneuzuWgnaYngsp63QDSkNnCL6bZ3bi4E3EqWy8zAiEmex2avsyOZMODlkFhpe+PZaO5KvDESWm3XbgXFZAq5pQmIW8Cd4kAnTtS4tM/BxvlZYXWfIMZg6rnoabhO9zxoGWM7g4oiX7fR6AL6vT+Jo6q8rP8e/kNiff0M6WodeuW+rIKmi0rbEa/DL4TD2YUzNZBuGIluzPgSAXSTvgspsEJIivweekLrjPK/tum2Vx8f5MY5mcDQ0OWYY4hN6UPqoTV3bgXoXm6mUqrhJnc8FNAoOII7M/P43NvRYjEZ8F6DNT6Us6AmDFkMZyk+Le35yYpjNN8980pgE3RRYHkHKlcwDXO+KBq7cAF8nMypxHswzpb+tE4tJMluAowY2r0jQHHj7gcLaT8ee4APRVhyPrPFleAGzFSVoMX71F0XF2NvvR+GMOBZCNJKrp7y8tGHFzjigbFmIzWtDe+WhiHEwWSjPo5Dr70RhxdqsxkQxMpUxrWM4H/L/1smHbkckCTjZvhzp+GhZIetEL2JG/IMBwUfvBwIbF1JUN0MQzKjTdpCxOQOVDbAnLFu3FxxhWlkp+aNmuQVTzZCNOT4TzGDn4wfZCY/w4uwAm+xhXelRj3hS/w7C8rLanLqUEOueylS6e8/5GauHkHdsKN6QZjuslJdwnL9zCOFiaW0weTx2PhNn5VZrcNJsxJWC4XpzcAtOcvuGB4mKp4TKq5+RSMrYqmYcmLLVsvxpu7DfnmtgqV1VQHC1Rxy2s5Hkhzmivw8GR12sAPvf/0vL85FLWzFS6aQsIWaG122qeXKY8rbiWltIADd/MteFVl3NYUKZ4ZRgwKFe4x9Q4ouf30anirWykOZgEz+lQOfdRyiggRHm2M7XRMV7B/3b+p9ini7ek2YD2z3FxdLzkHNUFoiMGsfd3phlW3hr5RK94/XygUAoTj05r52r1JGb8aEwQAmajbKVbjBvUPflQcLIu41sAdCYhARCbLlZfT+RhxxgDVvrYlWaDiilNUAzfUzgHToO7qlbxjrN8hbtaxOSyYs1pIY4fvQWqRNqz/YGq51qBGIOlrLn4u09Rma2Yc3f90nyTF4yUNePx3UcDFoTn8+3ay0IOMiEkCNNVZ4Xk/g2Tjy9Rd1StssuGonOVG4aV+8epeykwMU9ltu6N5dx7JZ+iwnQOjr3OVTqkfo38sfyxei6uuYJzsi4TtzpHuCcQpl5jsv96Bu+TGaTjNjkT4a2sWmvrcCYB7etWohvYJY/t/plhH65P5S7zzV/JMD7gVjzuxkNKh+rXWj8auEn5YWf7nii17dB31uwX5ESC1kwNygDoH0wYbZQN6NM2vc8P4PZk4hICzW/1/EtEbZNK/QweWM34XEdc3tD3TI1754NREIo0lGE57gAc1xGwOAxj6Mnx/7Us/g7+3tyrmnMY2Hd74JSgy4XOKxoRFwni/vUine8KuC/sxX6SpbewLopA5JZaoFNQFHUUhuXtfE6Pl6xJkqryff7vP6oqSbJjymOJ4kRs2zYZnXY9Zp8X5REbuAwh+E8mKiNoV8EIbV3pDvBjfiYTMAXsHvh/8j8lGk64cpqoDy+yPy/jOhw6BgxrxDSrwPxUR1pswt50JOe+6fLfYC+b4uGFnzLa7Hedm7k0R+V9joLfb+K2eVzsX3jvM4jHe4e+CDDnnnx24XaHqO92WTCQdcpFLT9/3v983uvOQLxeRVJ2ifM895rTXncHrDpULUEsgMHT4i0ALFq17C0OJUesGwDTtYdEuUfY6XYaclK6M1cLRlLvsWO4iH2luSIut9dlmKRfauFzGryxqJGg+l75rldveRUS2PPLKZSQjAeCa1Ih329FMkJJomFlKhg26UT0I/TtpwP0NL9ySw9WE33X6FAUVtuNusqziHyNDsFhs+0UAq+JBmoU16BiXvcYN57U5uqRGjHDap85N7kfTpX8aIH75eW6hwhacOIbWUvasI2PMy45WxVuVbPlhgcwW1Ku+cA/QtngHpfmkKYAAAAASUVORK5CYII=
  lqip: data:image/webp;base64,UklGRpoAAABXRUJQVlA4WAoAAAAQAAAADwAABwAAQUxQSDIAAAARL0AmbZurmr57yyIiqE8oiG0bejIYEQTgqiDA9vqnsUSI6H+oAERp2HZ65qP/VIAWAFZQOCBCAAAA8AEAnQEqEAAIAAVAfCWkAALp8sF8rgRgAP7o9FDvMCkMde9PK7euH5M1m6VWoDXf2FkP3BqV0ZYbO6NA/VFIAAAA
  alt: TIL image
---

[PDF](https://github.com/eomjinyoung/bitcamp-study/blob/main/docs/%EC%8A%A4%ED%94%84%EB%A7%81%ED%94%84%EB%A0%88%EC%9E%84%EC%9B%8C%ED%81%AC1.pdf)

# Review
* @SessionAttributes, @ModelAttribute를 사용하여 세션 값을 제어할 수 있는가?
* 인터셉터의 구동에 대해 설명하고 구현하고 설정할 수 있는가?
* HttpMessageConverter에·대해 설명할 수 있는가? 
* 요청으로 보낸 JSON 데이터를 객체로 자동 변환하여 request handler의 파라미터로 받을 수 있는가?
* request handler가 리턴한 객체를 JSON 데이터로 자동 변환하여 응답할 수 있는가?


# myapp을 javaConfig 사용하도록 변경하기
...아주빠른실습

## 파라미터로 맵 객체를 받은 경우,
맵 객체에 뭔가를 새로 넣었을 때 쿼리스트링으로 자동으로 붙는다!!! 페이지 컨트롤러에서 붙여서 DispatcherServlet에 넘기기 때문. 명시되어 있지 않으므로 주의하기

# 드디어 MyBatis 도입
MyBatis가 무엇인가? java에서 SQL을 통해 DB를 다루려면 SQL문과 JDBC를 이용해야 했다. 그래서 java 문서 하나에 SQL 문도 들어가다보니 길다란 스트링 `SELECT ~~~~~~~~~~~~~~~~~` 이 생겼다. 이런 긴 문자열들에 컴파일러가 뭔가를 체크해줄 수도 없고, 린터가 들어가지도 않으니 가독성이 많이 떨어지며, java와 SQL을 오가며 작성하는 것이 매우 비효율적이었다. 이것을 해결해주기 위해 MyBatis가 등장했다.

## 원리는 기존 JDBC, SQL 동일
MyBatis 또한 그 SQL, JDBC를 이용한 것이다. 다만 그에 대한 인터페이스를 제공하여 JDBC와 SQL 을 좀 더 다루기 쉽게 해준 것이다.



# DB를 쓰는 프로그램을 작성하는 두 가지 방법
1. 직접 SQL 문을 작성하여 DBMS에 작업을 요청하는 경우
2. API를 통해 생성된 SQL문이 DBMS에 작업을 요청하는 경우

여기서 1번은 SQL Mapper라고 한다. 대표적인 프레임워크로는 MyBatis 가 있다.
2번은 OR Mapper 라고 한다. Object-Relation Mapper 이다. 대표적으로는 Hibernate를 포장한 Java Persistance API (JPA) 가 있다.

무슨 차이가 있나? 만약 DBMS가 바뀌는 경우라면?

SQL Mapper를 사용한다면 작성자가 SQL을 잘 알고 있어야 한다. DBMS 특성에 맞춰서 SQL을 직접 작성해야 하기 때문이다. 그래서 좀 번거롭다는 단점도 생기지만, 반대로 최적화된 쿼리를 작성하여 DBMS의 성능을 최대로 뽑아낼 수 있다는 장접도 있다.

OR Mapper를 사용한다면 작성자가 SQL을 자세히는 모르더라도, 아마도 사용하기에는 언어가 동일하므로 조금 더 쉬울 것이다. DBMS에 대한 종속성도 조금은 낮출 수 있다. 유지보수가 더 쉬워질 것이다. 하지만 DBMS의 성능을 최대로 활요하기로 기대하기는 어려울 것이다. 그리고 DBMS 회사에서 해당 OR Mapper와의 API를 제대로 지원하지 않 으면 문제가 될 것이다.

### Legacy 에 대하여
레거시에 SI하는 경우 OR Mapper를 적용하는 것이 나쁜 선택이 될 수도 있다. SQL문도 작성하고 API도 사용해야 하는, 복잡도를 높이는 선택이 될 수 있기 때문이다. 그리고 OR Mapper도 결국은 SQL문을 API를 통해 생성하는 것인데, SQL에 익숙하지 않은 경우라면 SQL Mapper를 사용하여 SQL도 연습하는 것이 좋다.

### 학습을 한다면
학습을 한다면, Java와 디자인패턴을 배운 다음에 Spring의 IoC 개념을 배운다. 

JDBC를 배워야 MyBatis를 이해할 수 있다. MyBatis를 배운 다음에 JPA를 배울 수 있다.

Servlet을 이햏둬야 Spring webMVC를 이해할 수 있다. Spring WebMVC를 배우고 나면 RESTful 의 필요성을 느끼고, 그 다음에 Spring Boot를 배우면 적절하다.

HTML, CSS, JS를 다 배우면, 
JS를 좀 더 파서 JQuery를 배울 수 있고, Bootstrap을 배울 수 있고 AJAX를 배울 수 있다. 이것들을 다 배워봤다면 React를 배워볼만하다.

# MyBatis에서 DB 컬럼명과 동일한 vo의 필드들에 넣어주는데...
그럼 java에서 sql 컨벤셔에 따라 컬럼을 네이밍할까?

아니면 sql 컬럼 이름을 java의 네이밍 컨벤션에 따라 변경할까?

둘 다 그렇게 하지 마라! 각각의 컨벤션이 있고 그것을 존중해라. MyBatis에서도 alias와 같이 이러한 네이밍 컨벤션의 간극을 해결하기 위한 방법을 제공한다.