---
title: (Day	72) 서블릿의 동작구조
author: 김준회
date: 2024-02-27 17:00:00 +0900
categories: [TIL, 비트캠프]
tags: [TIL, Web, 비트캠프, 네이버클라우드]
pin: true
math: true
mermaid: true
image:
  path: /commons/today-i-learned.png
  lqip: data:image/webp;base64,UklGRpoAAABXRUJQVlA4WAoAAAAQAAAADwAABwAAQUxQSDIAAAARL0AmbZurmr57yyIiqE8oiG0bejIYEQTgqiDA9vqnsUSI6H+oAERp2HZ65qP/VIAWAFZQOCBCAAAA8AEAnQEqEAAIAAVAfCWkAALp8sF8rgRgAP7o9FDvMCkMde9PK7euH5M1m6VWoDXf2FkP3BqV0ZYbO6NA/VFIAAAA
  alt: TIL image
---
벌써 72일째네..
# REVIEW
* 서블릿간 공유하는 객체 : ServletRequest, ServletRequest. 
  * 라이프사이클: 요청이 들어오면 생성되고, 응답이 끝나면 삭제되는 생명주기를 가진다.
* forward / include

# TIL
서블릿의 동작구조를 알면 스프링 프레임워크도 이해하기 쉬워진다.

![](https://blog.kakaocdn.net/dn/dxHAlz/btqBGYZX1wa/Cdgc00ZuYf0SBxI2CtQuOk/img.jpg)